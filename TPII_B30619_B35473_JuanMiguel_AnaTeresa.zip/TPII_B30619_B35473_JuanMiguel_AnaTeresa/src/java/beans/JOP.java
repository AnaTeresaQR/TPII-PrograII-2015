package beans;

public class JOP {

    String msj = "";

    public JOP() {
        msj = "";
    }

    public String getMsj() {
        return msj;
    }

    public void setMsj(String msj) {
        this.msj = msj;
    }

}
